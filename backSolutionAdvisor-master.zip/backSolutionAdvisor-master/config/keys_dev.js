module.exports = {
    mongoURI:
      "mongodb+srv://yomnasherif:secretpassword@cluster0.lrgtr.mongodb.net/SolutionAdvisor?retryWrites=true&w=majority",
    secretOrKey: 'verysecretkey'
  }